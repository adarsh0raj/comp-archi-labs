#ifndef MADCACHE_H
#define MADCACHE_H

#include "cache.h"

#ifdef T1_BYPASS

// PC PREDICTOR TABLE
#define PC_PREDICTOR_TABLE_SIZE 1024
#define PC_PREDICTOR_COUNTER_SIZE 6
#define PC_PREDICTOR_ENTRY_SIZE 9

// TRACKER SET
#define TRACKER_SIZE LLC_SET/16

// DEFAULT POLICY
#define DEFAULT_POLICY_COUNTER_SIZE 10

// class to represent pc predictor table entry
class PC_PREDICTOR_TABLE_ENTRY {
  public:
    uint64_t pc;        // 64 bits
    uint8_t counter;    // 6 bits
    uint16_t entries;   // 9 bits

    // constructor
    PC_PREDICTOR_TABLE_ENTRY() {

        counter = 31;
        entries = 0;
    }

    uint8_t get_counter();
    void increment_counter(),
    decrement_counter();

    uint16_t get_entries();
    void increment_entries(),
    decrement_entries();

    uint64_t get_pc();
    bool get_msb(),
    get_policy();
};

PC_PREDICTOR_TABLE_ENTRY pc_predictor_table[PC_PREDICTOR_TABLE_SIZE];

// ppte: pc predictor table entry
// return the index in the pc predictor table based on pc
int get_ppte(uint64_t pc) {
    for (int i=0; i<PC_PREDICTOR_TABLE_SIZE; i++) {
        if ((pc_predictor_table[i].get_pc() == pc) && (pc_predictor_table[i].get_entries() > 0));
            return i;
    }
    return -1;
}

// add a ppte corresponding to given pc if doesn't exist
void add_ppte(uint64_t pc) {
    for (int i=0; i<PC_PREDICTOR_TABLE_SIZE; i++) {
        if (pc_predictor_table[i].get_entries() <= 0) {
            pc_predictor_table[i].pc = pc;
            pc_predictor_table[i].counter = 31;
            pc_predictor_table[i].entries = 1;
            return;
        }
    }
}

// default policy structure
class DEFAULT_POLICY {
  public:
    uint16_t counter; // 10 bits

    // constructor
    DEFAULT_POLICY() {
        counter = 511;
    }

    uint16_t get_counter();
    void increment_counter(),
    decrement_counter();
    
    bool get_msb(),
    get_policy();
};

DEFAULT_POLICY default_policy;

// class to denote a cacheline in tracker sets
class TRACKER_CACHELINE {
  public:
    bool valid, reuse;
    uint64_t index;

    // constructor
    TRACKER_CACHELINE() {

        valid = 0;
        reuse = 0;
        index = 0;
    }

    bool get_valid_bit(),
    get_reuse_bit();
    uint64_t get_index();

    void set_valid_bit(),
    set_reuse_bit();
};

class TRACKER_SET {
  public:
    TRACKER_CACHELINE tracker_set[TRACKER_SIZE][LLC_WAY];
    int is_tracker[TRACKER_SIZE];
    map<int, int> inverse_map;

    // constructor
    TRACKER_SET() {

        // selecting the tracker set using dynamic set sampling
        uint16_t arr[LLC_SET];
        for(int i=0; i<LLC_SET; i++)
            arr[i] = i;
        std::srand(3);
        std:random_shuffle(arr, arr+LLC_SET);
        for(int i=0; i<TRACKER_SIZE; i++) {
            is_tracker[i] = arr[i];
            inverse_map.insert({arr[i], i});
        }
    }
};

TRACKER_SET tracker;

#endif

#endif
